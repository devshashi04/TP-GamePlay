
self.addEventListener('install', function (e) {
    console.log('[Service Worker] Install');
    
});

